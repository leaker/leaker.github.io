#!/usr/bin/env python
# coding: utf-8
# 功能：将M8导出的联系人XML转化成Andriod可以导入的vcf文件
# 版本：python 2.6 以上
# 作者：leaker
# 网站：www.leelib.com
from xml.etree import ElementTree as ET

# 输出到的mycontact.vcf
out = file("mycontact.vcf", "wb")
root = ET.parse(file("mycontact.xml", "r")).getroot()
print root
for e in root.findall('Person'):
    out.write('BEGIN:VCARD\r\nVERSION:3.0\r\n')
    out.write('N:%s;%s;;;\r\n' %
        (e.findtext('LastName', '').encode('utf8'), e.findtext('FirstName', '').encode('utf8')))
    out.write('FN:%s\r\n' % (e.findtext('FileAs', '').encode('utf8')))
    # print 'FN:%s\r\n'% (e.findtext('FileAs', '').encode('gb2312'))
    for ee in root.findall('Phone'):
		if ee.findtext('PersonID','') == e.findtext('ID',''):
			primary = ee.get('IsPrimary') == 'true'
			out.write('TEL;TYPE=CELL%s:%s\r\n' % ((';TYPE=PREF' if primary else ''), ee.findtext('Info','')))
    out.write('END:VCARD\r\n')
out.close()